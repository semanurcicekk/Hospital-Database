SELECT * FROM hospital.medicine;

INSERT INTO medicine (MedicationName, PrescriptionNo, ProductionDate, ExpiryDate, StockStatus)
VALUES ('PARANOX', 'M70531', '2020-11-03', '2023-01-01', 0);

